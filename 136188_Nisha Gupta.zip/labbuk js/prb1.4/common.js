var msg;
var sum;
 msg="<p><code>The actual script is in external script file called common.js</code></p>";
 function addNos(headVar,bodyVar)
 {
 //TODO: display the contents of the variable "msg" 
 document.write(msg);
 
 //TODO: display the addition of two numbers 
 sum=headVar+bodyVar;
 document.write("The sum of the variables <code>headVar</code> and <code>bodyVar</code> is <b>"+sum+"</b>");
 
 }