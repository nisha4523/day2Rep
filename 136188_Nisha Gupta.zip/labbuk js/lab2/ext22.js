function cmpd(){
var i;
for( i=0;i<65;i++)
document.write("-");
document.write("<br>**********Calculate Compound Interest**********<br>");
for(i=0;i<65;i++)
document.write("-");
var p=1000,n=1,r=10,ci=1;
var c=1+r/100;
for(i=0;i<n;i++)
ci*=c;
ci=ci*p-p;
document.write("<br>Principal&emsp;&emsp;&emsp;-&emsp;"+p+" rs");
document.write("<br>Rate of Interest&emsp;-&emsp;"+r+"%");
document.write("<br>Period &emsp;&emsp;&emsp;&emsp;-&emsp;"+n+" yr");
document.write("<br>Comp Interest&emsp;-&emsp;"+ci);
}
