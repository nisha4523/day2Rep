package com.capgemini.truckbooking.client; 

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.capgemini.truckbooking.bean.BookingBean;
import com.capgemini.truckbooking.bean.TruckBean;
import com.capgemini.truckbooking.exception.BookingException;
import com.capgemini.truckbooking.service.TruckService;

public class BookingClient
{
	public static void main(String[] args)
	{
		int choice;
		int status=0;
		String custId;
		long custMobile;
		LocalDate dateOfTransport;
		String inpDate;
		DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		int truckID,noOfTruckToBook;
		TruckBean tb1=new TruckBean();
		BookingBean bb1=new BookingBean();
		List<TruckBean> truckBeanList=new ArrayList<TruckBean>();
		TruckService ts1=new TruckService();
		Scanner sc=new Scanner(System.in);
		
		System.out.println("1.Book Trucks\n2.Exit");
		choice=sc.nextInt();
		if(choice==1)
		{
			System.out.println("Enter customer id:");
			custId=sc.next();
			try
			{
				ts1.validate(custId);
				truckBeanList=ts1.retrieveTruckDetails();
				Iterator<TruckBean> eIt=truckBeanList.iterator();
				System.out.println("Please see the truck details below:");
				System.out.println("TruckId\tTruckType\tOrigin\tDestination\tCharge\tAvailableNos");
			   
			     while(eIt.hasNext())
			     {
			    	 tb1=eIt.next();
			    	 System.out.println(tb1);
			     }
			     System.out.println("Please enter the truckId:");
			     truckID=sc.nextInt();
			     System.out.println("Enter number of trucks");
			     noOfTruckToBook=sc.nextInt();
			     
			     ts1.validate(truckID,noOfTruckToBook);
			     
			     System.out.println("Enter customer mobile:");
			     custMobile=sc.nextLong();
			     ts1.validate(custMobile);
			     System.out.println("Enter date of transportation in format yyyy-MM-dd");
			     inpDate=sc.next();
			     dateOfTransport= LocalDate.parse(inpDate, dateFormat);
			     ts1.validate(dateOfTransport);
			     
			     bb1=new BookingBean(custId,custMobile,truckID, noOfTruckToBook,dateOfTransport);
			     status=ts1.bookTrucks(bb1);
			     if(status!=0)
			        System.out.println("ThankYou. your booking id is "+bb1.getBookingID());
			     status=0;
			     status=ts1.updateTrucks(truckID, noOfTruckToBook); 
			} 
			catch (BookingException e)
			{
				e.printStackTrace();
			}
		}
		else if(choice==2)
		{
			System.exit(choice);
		}
		else
			System.out.println("Invalid Choice");

	}

}














