package com.capgemini.truckbooking.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.capgemini.truckbooking.bean.BookingBean;
import com.capgemini.truckbooking.bean.TruckBean;
import com.capgemini.truckbooking.exception.BookingException;
import com.capgemini.truckbooking.utility.DbUtil;

public class TruckDao implements ITruckDao
{
	private static Logger logger=Logger.getLogger(com.capgemini.truckbooking.dao.TruckDao.class);
	//one logger obj for all operation logging..hence static
	int bId=0;
	//to store booking id
	List<TruckBean> truckBeanList=new ArrayList<TruckBean>();
	TruckBean tb1=new TruckBean();
	
	@Override
	public int getBookingId() throws BookingException
	{
	//return the updated booking id	
		Connection connT;
		Statement stmt;
		String sql="SELECT booking_id_seq.nextval from dual";
		try 
		{
			connT=DbUtil.createConn();
			stmt=connT.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
			ResultSet rset = stmt.executeQuery (sql);
			if (rset.next())
			   bId=rset.getInt(1);   //store booking Id retrieved from DB
		}
		catch (SQLException e)
		{
			logger.error("Problem in reading from DB");
			throw new BookingException("Problem in reading from DB");
		}
		finally
		{
			try
			{
				DbUtil.closeConnection();
			}
			catch(SQLException se)
			{
				logger.error(" Problems in closing connection ");
				throw new BookingException("Problems in closing connection");
			}

		}
		logger.info("booking id: "+bId+" retrieved from DB");
		return bId;
	}

	@Override
	public List<TruckBean> retrieveTruckDetails() throws BookingException 
	{
		//return the arraylist of truckdetails fetched records
		Connection connT;
		Statement stmt;
		
		try {
			connT=DbUtil.createConn();	
			stmt = connT.createStatement (ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
		
		   ResultSet rset = stmt.executeQuery ("SELECT * from TruckDetails");
			while (rset.next())
			{
				tb1.setTruckID(rset.getInt(1));
				tb1.setTruckType(rset.getString(2));
				tb1.setOrigin(rset.getString(3));
				tb1.setDestination(rset.getString(4));
				tb1.setCharges(rset.getFloat(5));
				tb1.setAvailableNos(rset.getInt(6));
				truckBeanList.add(tb1); //to directly access bookingId from bookingbean obj 
				tb1=new TruckBean();
				
				logger.info("Truck with TruckId"+rset.getInt(1)+"displayed");
			}
		} 
		catch (SQLException e)
		{
			logger.error("Problem in reading from DB");
			throw new BookingException("Problem in reading from DB");
		}
		finally
		{
			try
			{
				DbUtil.closeConnection();
			}
			catch(SQLException se)
			{
				logger.error("Problems in closing connection");
				throw new BookingException("Problems in closing connection");
			}

		}
		return truckBeanList;
	}

	public int getAvailNos(int truckId) throws BookingException
	{
		//return noOfTruck for validation purpose 
		Connection connT ;
	    int nos=0;
	    CallableStatement cstT=null;
	try
	{
		connT=DbUtil.createConn();
		String sql=new String("{CALL ?:=retNos(?)}");    //calling sql functionretNos()
		cstT=connT.prepareCall(sql);
		cstT.registerOutParameter(1, java.sql.Types.NUMERIC);
		cstT.setInt(2, truckId);
		cstT.execute();
		nos=cstT.getInt(1);
					
	 }
		catch (SQLException e)
		{
			logger.error("Problem in reading from DB");
			throw new BookingException("Problem in reading from DB");
		}
		finally
		{
			try
			{
				DbUtil.closeConnection();
			}
			catch(SQLException se)
			{
				logger.error("Problems in closing connection");
				throw new BookingException("Problems in closing connection");
			}

		}
	logger.info("No of trucks as "+nos+"retrieved from db");   //in case no error occurred this will execute
	return nos;
	}
	
	@Override
	public int bookTrucks(BookingBean bookingBean) throws BookingException
	{
		//insertion of record into DB
		int status=0;
		Connection connT=null;
		PreparedStatement pstT=null;
		java.sql.Date date = java.sql.Date.valueOf(bookingBean.getDateOfTransport()); 
		//to convert sql date into LocalDate
		this.bId=getBookingId();
		bookingBean.setBookingID(bId);
		String sql=new String("INSERT INTO BookingDetails values(?,?,?,?,?,?)");
		
		try
		{
			connT=DbUtil.createConn();
			pstT=connT.prepareStatement(sql);
			pstT.setInt(1, bId);
			pstT.setString(2,bookingBean.getCustId());
			pstT.setLong(3,bookingBean.getCustMobile());
			pstT.setInt(4,bookingBean.getTruckId());
			pstT.setInt(5,bookingBean.getNoOfTrucks());
			pstT.setDate(6,date);
			
			status=pstT.executeUpdate();
				 
			logger.info("booking details inserted into db with booking id: "+bId);
		}
	 
	catch (SQLException e)
	{
		logger.error("Problem in inserting to  DB");
		throw new BookingException("Problem in inserting to  DB");
	}
	finally
	{
		try
		{
			DbUtil.closeConnection();
		}
		catch(SQLException se)
		{
			logger.error("Problems in closing connection");
			throw new BookingException("Problems in closing connection");
		}

	}   
		return status;
	}

	@Override
	public int updateTrucks(int truckId, int noOfTruckToBook) throws BookingException
	{
		//after insertion nooftrucks reduced in DB
		Connection connT ;
	   	int status=0;
	   	try
			{
	   		connT=DbUtil.createConn();
	   		PreparedStatement stmt;
	   		String sql=new String("update Truckdetails SET availableNos=availableNos-? where truckId=?");
				
			    stmt=connT.prepareStatement(sql);
			    stmt.setInt(1, noOfTruckToBook);
			    stmt.setInt(2,truckId);
			    status=stmt.executeUpdate();
			 }
	
	catch (SQLException e)
	{
		logger.error("Problem in updating DB");
		throw new BookingException("Problem in updating DB");
	}
	finally
	{
		try
		{
			DbUtil.closeConnection();
		}
		catch(SQLException se)
		{
			logger.error("Problem in closing connection");
			throw new BookingException("Problems in closing connection");
		}

	}
	    logger.info("number of trucks updated for truck id "+truckId);
	   	return status;
	}

	public int getBId()
	{
		return bId;
		//to access bookingId in service class and client class 
	}
}
























