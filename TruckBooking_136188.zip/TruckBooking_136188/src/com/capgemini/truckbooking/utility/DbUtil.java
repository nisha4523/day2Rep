package com.capgemini.truckbooking.utility;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class DbUtil
{
   private static Connection connT;
   public static Connection createConn() throws SQLException
   {
	   ResourceBundle resOracle=ResourceBundle.getBundle("oracle");
	   String url=resOracle.getString("url");
	   String username=resOracle.getString("username");
	   String password=resOracle.getString("password");
	   	   
	   DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
	   connT=DriverManager.getConnection(url,username,password);
	   
	   return connT;
   }
   public static void closeConnection() throws SQLException
   {
	   if(connT!=null)
		   connT.close();
   }
}
