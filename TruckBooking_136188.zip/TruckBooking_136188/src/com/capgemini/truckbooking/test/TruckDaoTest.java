package com.capgemini.truckbooking.test;

import java.time.LocalDate;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.truckbooking.bean.BookingBean;
import com.capgemini.truckbooking.dao.TruckDao;
import com.capgemini.truckbooking.exception.BookingException;

public class TruckDaoTest {
	TruckDao td1=null;
	BookingBean bb1=null;
	@Before
	public void setUp() throws Exception
	{
		 td1=new TruckDao();
		bb1=new BookingBean("A112233",1234567890,3005,1,(LocalDate.now().plusDays(2)));
			
	}

	@After
	public void tearDown() throws Exception 
	{
		td1=null;
		bb1=null;
	}

	@Test
	public void testGetAvailNos() throws BookingException
	{
		Assert.assertEquals(3,td1.getAvailNos(1000));
	}

	@Test
	public void testBookTrucks() throws BookingException
	{
		  Assert.assertEquals(1,td1.bookTrucks(bb1));
	}

	@Test
	public void testUpdateTrucks() throws BookingException
	{
		 Assert.assertEquals(1,td1.updateTrucks(1001,1));
	}

}
