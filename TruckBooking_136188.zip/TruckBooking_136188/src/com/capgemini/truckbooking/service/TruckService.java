package com.capgemini.truckbooking.service;

import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.truckbooking.bean.BookingBean;
import com.capgemini.truckbooking.bean.TruckBean;
import com.capgemini.truckbooking.dao.TruckDao;
import com.capgemini.truckbooking.exception.BookingException;

public class TruckService implements ITruckService 
{
	int bId;
	TruckDao td1=new TruckDao();
	TruckBean tb1=new TruckBean();
	List<TruckBean> truckBeanList=new ArrayList<TruckBean>();
	Pattern pCName=Pattern.compile("^[A-Z]+[0-9]{6}$");     //like A123456
	Pattern pMob=Pattern.compile("^[0-9]{10}$");            //10 digit mobile num
	Matcher m;
	
	@Override
	public List<TruckBean> retrieveTruckDetails() throws BookingException
	{
		truckBeanList=td1.retrieveTruckDetails();
		return truckBeanList;
	}

	@Override
	public int bookTrucks(BookingBean bookingBean) throws BookingException 
	{
		return (td1.bookTrucks(bookingBean));
		
	}

	@Override
	public int updateTrucks(int truckId, int noOfTruckToBook) throws BookingException {
		
		return td1.updateTrucks(truckId, noOfTruckToBook);
	}

	public void validate(String custId) throws BookingException
	{
		m=pCName.matcher(custId);
    	if(!m.find())
    		throw new BookingException("custId should start with capital followed by 6 digits");
    	
	}

	public void validate(int truckID,int noOfTruckToBook) throws BookingException
	{
		int nos=td1.getAvailNos(truckID);
		if(noOfTruckToBook<=0||noOfTruckToBook>nos)
			throw new BookingException("No of trucks should be>0 and <= available numbers");
   	}

	public void validate(long custMobile) throws BookingException
	{
		m=pMob.matcher(Long.toString(custMobile));
    	if(!m.find())
    		throw new BookingException("custMobile should be 10 digits");
    	
	}

	public void validate(LocalDate dateOfTransport) throws BookingException
	{
		LocalDate today = LocalDate.now();
		Period per=Period.between(today,dateOfTransport);
		if(per.getDays()<0)                      //if dateOftransport before current date
			throw new BookingException("dateOfTransport should be after current date");
    	
			
	}

	public int getBookingId() throws BookingException
	{
		bId=td1.getBId();
		return bId;
	}

}




























