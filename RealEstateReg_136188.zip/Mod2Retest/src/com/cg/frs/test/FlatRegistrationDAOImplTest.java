package com.cg.frs.test;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.cg.frs.dao.FlatRegistrationDAOImpl;
import com.cg.frs.dto.FlatRegistrationDTO;
import com.cg.frs.exception.FlatRegException;

public class FlatRegistrationDAOImplTest 
{
    FlatRegistrationDAOImpl fDAO;
    FlatRegistrationDTO fDTO;
    
	@Before
	public void setUp() throws Exception
	{
		fDAO=new FlatRegistrationDAOImpl();
		fDTO=new FlatRegistrationDTO(1, 1, 5000, 8000, 20000);
	}

	@After
	public void tearDown() throws Exception
	{
		fDAO=null;
	}

	@Test
	public void testOwnerIdList() throws FlatRegException
	{
		List<Integer> list=new ArrayList<Integer>();     //to store list of ownerIds from Table
		List<Integer> ownerL=new ArrayList<Integer>();    //to store list returned from function
		ownerL=fDAO.ownerIdList();
		list.add(1);
		list.add(2);
		list.add(3);
		Assert.assertEquals(true,list.equals(ownerL));      //if both lists are equal..
	}

	@Test
	public void testInsertRegDet() throws FlatRegException
	{
		Assert.assertEquals(1007,fDAO.insertRegDet(fDTO));
		//******NEED to provide next value of flat_seq from DB to test*****
	}

}
