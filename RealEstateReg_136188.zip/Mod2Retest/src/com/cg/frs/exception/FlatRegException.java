package com.cg.frs.exception;

public class FlatRegException extends Exception
{

	public FlatRegException()
	{
		super(); 
	}

	public FlatRegException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) 
	{
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public FlatRegException(String message, Throwable cause) 
	{
		super(message, cause);
	}

	public FlatRegException(String message) 
	{
		System.out.println(message); 
	}

	public FlatRegException(Throwable cause)
	{
		super(cause); 
	}

	private static final long serialVersionUID = 1L;

}
