package com.cg.frs.ui;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.cg.frs.dto.FlatRegistrationDTO;
import com.cg.frs.exception.FlatRegException;
import com.cg.frs.service.FlatRegistrationServiceImpl;

public class Client {

	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		FlatRegistrationServiceImpl fSer=new FlatRegistrationServiceImpl();
		FlatRegistrationDTO fDTO=new FlatRegistrationDTO();
		List<Integer> ownerL=new ArrayList<Integer>();
		int choice=0,id=0;
		
		System.out.println("1.Register Flat\n2.Exit");
		choice=sc.nextInt();
		switch(choice)
		{
		  case 1:
		  {
			  try
			  {
				System.out.print("Existing Owner IDS Are:-[");
				ownerL=fSer.ownerIdList();
				Iterator<Integer>OwnerIt=ownerL.iterator();
				while(OwnerIt.hasNext())
			     {
			    	 id=OwnerIt.next();
			    	 System.out.print(id+" ");
			     }
				System.out.println("]");
				System.out.print("Please Enter your owner id from above list: ");
				fDTO.setOwnerId(sc.nextInt());
				System.out.print("\nSelect Flat Type (1-1BHK,2-2BHK): ");
				fDTO.setFlatType(sc.nextInt());
				System.out.print("\nEnter flat area in sq. ft.: ");
				fDTO.setFlatArea(sc.nextInt());
				System.out.print("\nEnter desired rent amount Rs: ");
				fDTO.setRentAmount(sc.nextDouble());
				System.out.print("\nEnter desired deposit amount Rs: ");
				fDTO.setDepositAmount(sc.nextDouble());
				fSer.validate(fDTO);
				//code below will run if validate doecnot throw exception ie input type,rent,deposit are valid
				int status=fSer.insertRegDet(fDTO);
				if(status!=0)
				   System.out.println("Flat successfully registered.Registration id: <"+status+">.");
			  }
			  catch (FlatRegException e)
			  {
				System.out.println(e.getMessage());
			  }
			  
			  break;
		  }
		  case 2:
		  {
			  System.exit(0);
			  break; 
		  }
		  default:System.out.println("Invalid choice...");
		  break;
		}

	}

}






























