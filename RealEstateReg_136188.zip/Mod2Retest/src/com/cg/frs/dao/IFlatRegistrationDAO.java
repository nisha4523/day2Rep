package com.cg.frs.dao;

import java.util.List;

import com.cg.frs.dto.FlatRegistrationDTO;
import com.cg.frs.exception.FlatRegException;

public interface IFlatRegistrationDAO {

	List<Integer> ownerIdList() throws FlatRegException;

	int insertRegDet(FlatRegistrationDTO fDTO) throws FlatRegException;

}
