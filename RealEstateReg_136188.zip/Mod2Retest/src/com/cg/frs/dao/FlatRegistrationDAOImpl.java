package com.cg.frs.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.cg.frs.dto.FlatRegistrationDTO;
import com.cg.frs.exception.FlatRegException;
import com.cg.frs.utility.DbUtil;

public class FlatRegistrationDAOImpl implements IFlatRegistrationDAO 
{
  private static Logger logger=Logger.getLogger(com.cg.frs.dao.FlatRegistrationDAOImpl.class);
  //one logger object for whole class hence static
  Connection conn;
  PreparedStatement pst;
  
  List<Integer> ownerL=new ArrayList<Integer>();

  @Override
  public List<Integer> ownerIdList() throws FlatRegException
  {
	  String sql="select owner_id from flat_owners";
	  int id;
	  try {
			conn=DbUtil.createConn();	
			pst=conn.prepareStatement(sql);
		    ResultSet rset = pst.executeQuery();       //to store records fetched from query
			while (rset.next())
			{
				id=(rset.getInt(1));
				ownerL.add(id);
				
			}
			logger.info("List of ownerIds retreived from DB");
		} 
		catch (SQLException e)
		{
			logger.error("Problem in reading from DB");
			throw new FlatRegException("Problem in reading from DB");
		}
		finally
		{
			try
			{
				DbUtil.closeConnection();
			}
			catch(SQLException se)
			{
				logger.error("Problems in closing connection");
				throw new FlatRegException("Problems in closing connection");
			}

		}
	  return ownerL;
  }

  @Override
  public int insertRegDet(FlatRegistrationDTO fDTO) throws FlatRegException
  {
	  int status=0;
	  int fRegNo=0;
	  String sql="insert into flat_registration values (flat_seq.nextval,?,?,?,?,?)";
      try
	  {
		  conn=DbUtil.createConn();
		  pst=conn.prepareStatement(sql);
		  pst.setInt(1, fDTO.getOwnerId());
		  pst.setInt(2, fDTO.getFlatType());
		  pst.setInt(3, fDTO.getFlatArea());
		  pst.setDouble(4, fDTO.getRentAmount());
		  pst.setDouble(5, fDTO.getDepositAmount());
		  
		  status=pst.executeUpdate();                   //returns number of records updated
		  if(status==1)
		   {
			 Statement s=conn.createStatement() ;
			 ResultSet rs=s.executeQuery("select flat_seq.currval from dual");
			 if(rs.next())
				 fRegNo=rs.getInt(1);
			 logger.info("flat registration details inserted with regId="+fRegNo);
		   }
	  }
	  catch (SQLException e)
		{
			logger.error("Problem in reading from DB");
		  if(e.getErrorCode()==2291)      //2291 means parentkey not found exception in sql
			  throw new FlatRegException("<<owner does not exist>>");
		  else
			  throw new FlatRegException("Problem in inserting to DB");
		}
		finally
		{
			try
			{
				DbUtil.closeConnection();
			}
			catch(SQLException se)
			{
				logger.error("Problems in closing connection");
				throw new FlatRegException("Problems in closing connection");
			}

		}
	  return fRegNo;                  //returns FlatRegNo to access it in client 
  }

}



























