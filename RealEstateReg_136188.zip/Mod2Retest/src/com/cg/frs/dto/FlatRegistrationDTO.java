package com.cg.frs.dto;

public class FlatRegistrationDTO 
{

	private int flatRegNo;
	private int ownerId;
	private int flatType;
	private int flatArea;
	private double rentAmount;
	private double depositAmount;
	public FlatRegistrationDTO()
	{
		super();
	}
	public FlatRegistrationDTO(int ownerId, int flatType,
			int flatArea, double rentAmount, double depositAmount)
	{
		this.ownerId = ownerId;
		this.flatType = flatType;
		this.flatArea = flatArea;
		this.rentAmount = rentAmount;
		this.depositAmount = depositAmount;
	}
	@Override
	public String toString()
	{
		return "FlatRegistrationDTO [flatRegNo=" + flatRegNo + ", ownerId="
				+ ownerId + ", flatType=" + flatType + ", flatArea=" + flatArea
				+ ", rentAmount=" + rentAmount + ", depositAmount="
				+ depositAmount + "]";
	}
	public int getFlatRegNo()
	{
		return flatRegNo;
	}
	public void setFlatRegNo(int flatRegNo)
	{
		this.flatRegNo = flatRegNo;
	}
	public int getOwnerId() 
	{
		return ownerId;
	}
	public void setOwnerId(int ownerId)
	{
		this.ownerId = ownerId;
	}
	public int getFlatType()
	{
		return flatType;
	}
	public void setFlatType(int flatType) 
	{
		this.flatType = flatType;
	}
	public int getFlatArea()
    {
		return flatArea;
	}
	public void setFlatArea(int flatArea)
	{
		this.flatArea = flatArea;
	}
	public double getRentAmount()
	{
		return rentAmount;
	}
	public void setRentAmount(double rentAmount)
	{
		this.rentAmount = rentAmount;
	}
	public double getDepositAmount() 
	{
		return depositAmount;
	}
	public void setDepositAmount(double depositAmount) 
	{
		this.depositAmount = depositAmount;
	} 
	
}
