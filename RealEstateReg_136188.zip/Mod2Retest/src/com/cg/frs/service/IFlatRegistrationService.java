package com.cg.frs.service;

import java.util.List;

import com.cg.frs.dto.FlatRegistrationDTO;
import com.cg.frs.exception.FlatRegException;

public interface IFlatRegistrationService {

	List<Integer> ownerIdList() throws FlatRegException;

	void validate(FlatRegistrationDTO fDTO) throws FlatRegException;

}
