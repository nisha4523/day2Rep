package com.cg.frs.service;

import java.util.List;

import com.cg.frs.dao.FlatRegistrationDAOImpl;
import com.cg.frs.dto.FlatRegistrationDTO;
import com.cg.frs.exception.FlatRegException;

public class FlatRegistrationServiceImpl implements IFlatRegistrationService 
{
	FlatRegistrationDAOImpl fDAO=new FlatRegistrationDAOImpl();
	
	@Override
	public List<Integer> ownerIdList() throws FlatRegException
	{
		return fDAO.ownerIdList(); 
	}
	@Override
	public void validate(FlatRegistrationDTO fDTO) throws FlatRegException
	{
		int type=fDTO.getFlatType();
		double rent=fDTO.getRentAmount();
		double deposit=fDTO.getDepositAmount();
		if(type!=1&&type!=2)
			throw new FlatRegException("Invalid Flat type");
		if(deposit<rent)                                    //this will run if type is valid
			throw new FlatRegException("Deposit amount cannot be less than rent");
	}
	public int insertRegDet(FlatRegistrationDTO fDTO) throws FlatRegException
	{
		return fDAO.insertRegDet(fDTO);
	}
}
